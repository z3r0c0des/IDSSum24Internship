<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet"href="styling.css"/>
    <title>Home Page</title>

</head>
<body>
    <div class="container">
        <h1>Welcome</h1>
        <a href="loginp.html" class="button">Login</a>
        <a href="registerp.html" class="button">Register</a>
    </div>
</body>
</html>
